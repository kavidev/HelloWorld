import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;
public class DateFormatSample {
	public static void main(String[] args) {
		TimeZone timezone = TimeZone.getTimeZone("Asia/Tokyo");
		Locale locale = Locale.JAPAN;
		Calendar cal = Calendar.getInstance(timezone, locale);
		DateFormat df = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss z");
		String date = df.format(cal.getTime());
		System.out.println(date);
		cal.add(Calendar.YEAR, 2);
		cal.add(Calendar.MONTH, -2);
		cal.add(Calendar.DATE, 3);
		cal.add(Calendar.HOUR, 2);
		cal.add(Calendar.MINUTE, -17);
		cal.add(Calendar.SECOND, 30);
		date = df.format(cal.getTime());
		System.out.println(date);
	}
}
