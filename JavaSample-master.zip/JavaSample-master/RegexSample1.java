import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexSample1 {
	
	public static void main(String[] args) {
		String target = "『aa』aa『bb』bb";
		String regex = "『.+?』";
		
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(target);
		
		StringBuffer afterTarget = new StringBuffer();
		while(matcher.find()) {
			matcher.appendReplacement(afterTarget, matcher.group().toUpperCase());
		}
		
		matcher.appendTail(afterTarget);
	}
}