public class EnumSample {
	enum Yobi {
		MON("Monday"),
		TUE("TUESDAY"),
		WED("WEDNESDAY"),
		THU("THURSDAY"),
		FRI("FRIDAY"),
		SAT("SATURDAY"),
		SUN("SUNDAY");
		private String name = null;
		Yobi(String a) {
			name = a;
		}
		public String getName() {
			return name;
		}
	}
	public static void main(String[] args) {
		Yobi y = Yobi.MON;
		System.out.println(y.getName());
		for (Yobi y1 : Yobi.values()) {
			System.out.println(y1.getName());
		}
	}
}
