import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import java.io.*;
public class StAXSample {
	private final static String S1 = "<";
	private final static String S2 = ">";
	private final static String S3 = "</";
	public static void main(String[] args) {
		XMLInputFactory factory = XMLInputFactory.newInstance();
		XMLStreamReader reader = null;
		try (BufferedInputStream stream = new BufferedInputStream(new FileInputStream("sample.xml"));){
			reader = factory.createXMLStreamReader(stream);
			while (reader.hasNext()) {
				int a = reader.next();
				if (a == XMLStreamReader.START_ELEMENT) {
					System.out.println(S1 + reader.getName() + S2);
				} else if (a == XMLStreamReader.CHARACTERS) {
					if (!reader.isWhiteSpace()) {
						System.out.println(" " + reader.getText());
					}
				} else if (a == XMLStreamReader.END_ELEMENT) {
					System.out.println(S3 + reader.getName() + S2);
				}
				
			}
		} catch (FileNotFoundException|XMLStreamException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (XMLStreamException e) {
					e.printStackTrace();
				}
			}
		}
	}
}