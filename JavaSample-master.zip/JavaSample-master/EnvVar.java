public class EnvVar
{
	public static void main(String[] args)
	{
		System.out.println(System.getenv("PATH"));	
	}
}

