import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.*;
import org.xml.sax.SAXException;


public class XMLSample {

	/**
	 * @param args
	 * @throws ParserConfigurationException 
	 * @throws IOException 
	 * @throws SAXException 
	 */
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document document = builder.parse("Book.xml");
		NodeList list1 = document.getChildNodes();
		System.out.println("NodeName="+list1.item(0).getNodeName());
		NodeList list2 = list1.item(0).getChildNodes();
		for(int i=0;i<list2.getLength();++i)
		{
			if(list2.item(i).getNodeType()==Node.ELEMENT_NODE)
			{
				Element element = (Element)list2.item(i);
				System.out.println("NodeName="+element.getNodeName()+" value="+element.getFirstChild().getNodeValue());
			}

		}
	}

}
