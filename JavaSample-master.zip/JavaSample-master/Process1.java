import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.List;


public class Process1 {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		Process process = new ProcessBuilder("ls").directory(new File("/home")).start();
		BufferedReader input = new BufferedReader(new InputStreamReader(process.getInputStream()));
		String str = input.readLine();
		while(str!=null&&!str.equals(""))
		{
			System.out.println(str);
			str = input.readLine();
		}
	}

}
