import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TableMetaData {

	public static void main(String[] args) throws SQLException {
		String url = "jdbc:mysql://localhost:3306/TEST";
		String user = "root";
		String password = "root";
		
		Connection connection = DriverManager.getConnection(
				url, user, password);
		
		DatabaseMetaData databaseMetaData = connection.getMetaData();

		ResultSet resultSet = databaseMetaData.getColumns(null, "TEST",
				"table1", null);
		
		System.out.println("|TABLE_NAME           |COLUMN_NAME          |TYPE_NAME   |");
		while (resultSet.next()) {
			System.out.print("|");
			System.out.printf("%22s", resultSet.getString("TABLE_NAME") + "|");
			System.out.printf("%22s", resultSet.getString("COLUMN_NAME") + "|");
			System.out.printf("%13s\n", resultSet.getString("TYPE_NAME") + "|");
		}
	}
}
