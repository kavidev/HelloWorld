import java.util.*;
public class GenericsSample1 {
	public static void main(String[] args) {
		List<Animal> list1 = new ArrayList<Animal>();
		list1.add(new Dog());
		List<Dog> list2 = new ArrayList<Dog>();
		list2.add(new Dog());
		a(list1);
		a(list2);
	}
	static void a(List<? extends Animal> list) {
		System.out.println(list.get(0));
	}
	static void b(List<? super Dog> list) {
		list.add(new Dog());
	}
}

class Animal{}
class Dog extends Animal{}
