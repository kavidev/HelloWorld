import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Timestamp;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Clock extends JFrame implements ActionListener {

	JLabel label = new JLabel();

	public Clock() {
		JPanel panel1 = new JPanel();
		panel1.setLayout(new BorderLayout());
		JPanel panel2 = new JPanel();
		JButton button = new JButton("close");
		button.addActionListener(new ActionListener() {
		
			@Override
			public void actionPerformed(ActionEvent arg0) {
				System.exit(1);
			}
		});
		Timestamp timestamp = new Timestamp(new Date().getTime());
		String date = timestamp.toString().substring(0,19);
		date = date.replace("-", "/");
		label.setFont(new Font("MS �S�V�b�N", Font.CENTER_BASELINE, 16));
		label.setText(date);
		label.setHorizontalAlignment(JLabel.CENTER);
		panel1.add(label,BorderLayout.CENTER);
		panel2.add(button);
		Timer time = new Timer(1000, this);
		time.start();
		Container container = getContentPane();
		container.add(panel1,BorderLayout.CENTER);
		container.add(panel2,BorderLayout.SOUTH);

	}

	public static void main(String[] args) throws InterruptedException {
		Clock frame = new Clock();
		frame.setTitle("clock");
		frame.setBounds(300, 300, 300, 300);
		frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		Timestamp timestamp = new Timestamp(new Date().getTime());
		String date = timestamp.toString().substring(0,19);
		date = date.replace("-", "/");
		label.setText(date);		
	}

}
