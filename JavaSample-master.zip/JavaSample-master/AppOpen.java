import java.awt.Desktop;
import java.net.URI;
import java.net.URISyntaxException;
import java.io.File;
import java.io.IOException;
public class AppOpen {
	public static void main(String[] args) {
		if (args.length != 2) {
			throw new IllegalArgumentException("java AppOpen [URI] [browse] or java AppOpen [path] [text]");
		}
		try {
		Desktop desktop = Desktop.getDesktop();
		if (args[1].equals("browse")) {
			desktop.browse(new URI(args[0]));
		} else if (args[1].equals("text")) {
			desktop.edit(new File(args[0]));
		} else {
			System.out.println("java AppOpen [URI] [browse] or java AppOpen [path] [text]");
		}
		} catch (IOException | URISyntaxException e) {
			e.printStackTrace();
		}
	}
}