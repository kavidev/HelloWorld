import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Grep {
	
	public static void main(String[] args) {
		if ( args.length != 2 ) { throw new IllegalArgumentException();}

		File dir = new File(args[0]);
		if (dir.isDirectory()) {
			search(dir, args[1]);
		} else {
			System.out.println(args[0] + " is not exist");
		}
	}
	
	static void search(File file, String target) {
		File[] list = file.listFiles();
		for (File f : list) {
			if (f.isDirectory()) {
				search(f, target);
			}
			if (f.isFile()) {
				find(f, target);
			}
		}
	}
	
	static void find(File file, String target) {
		BufferedReader input = null;
		String regex = ".+" + target + ".+";
		Pattern p = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		try {
			input = new BufferedReader(new FileReader(file));
			String str = input.readLine();
			
			for (int i = 1; str != null; ++i ) {
				Matcher m = p.matcher(str);
				if (m.matches()) {
					System.out.println(i + "l " +file.getPath() + " : " + str);
				}
				str = input.readLine();
			}
			
		} catch (FileNotFoundException fe) {
			fe.printStackTrace();
		} catch (IOException ie) {
			ie.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				}
				catch (IOException ie) {
					ie.printStackTrace();
				}
			}
		}
	}
}