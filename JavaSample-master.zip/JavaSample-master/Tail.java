import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Tail {
	
	private static int lineNo = 10;

	public static void main(String[] args) {
		File file = null;
		// argument check
		if (args.length == 1) {
			file = new File(args[0]);
			if (!fileCheck(file)) {
				throw new IllegalArgumentException("java Tail [file]");
			}
			tailShow(file);
		} else if (args.length == 3) {
			file = new File(args[2]);
			if (!args[0].equals("-l") || !numberCheck(args[1]) || !fileCheck(file)) {
				throw new IllegalArgumentException("java -l [line number] [file]");
			}
			tailShow(file);
		}
	}
	
	private static boolean numberCheck(String s) {
		try {
			lineNo = Integer.parseInt(s);
		} catch (NumberFormatException e) {
			return false;
		}
		return true;
	}
	
	private static boolean fileCheck(File file) {
		if (file.isFile()) { 
			return true;
		} else {
			return false;
		}
	}
	
	private static void tailShow(File file) {
		BufferedReader input = null;
		
		try {
			input = new BufferedReader(new FileReader(file));
			String s = input.readLine();
			String[] s1 = new String[lineNo]; 
			String[] s2 = new String[lineNo];
			int i = 0;
			int j = 0;
			while (s != null) {
				if (i < lineNo) {
					s1[i++] = s;
					if (i == lineNo) {
						j = 0;
						initArray(s2);
					}
				} else {
					s2[j++] = s;
					if (j == lineNo) {
						i = 0;
						initArray(s1);
					}
				}
				s = input.readLine();
			}
			
			if (j > 0) {
				for (int l = j; l < lineNo; l++) {
					System.out.println(s1[l]);
				}
				for (int k = 0; k < j; k++) {
					System.out.println(s2[k]);
				}
			} else {
				for (int k = 0; k < i; k++) {
					System.out.println(s1[k]);
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (input != null) { input.close(); }
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	private static void initArray(String[] s) {
		for (int i = 0; i < s.length; i++) {
			s[i] = null;
		}
	}
	
}
