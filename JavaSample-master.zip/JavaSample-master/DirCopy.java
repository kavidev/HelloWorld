import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.SwingWorker;
import javax.swing.Timer;


public class DirCopy extends JFrame implements ActionListener {

	JProgressBar progress = new JProgressBar();

	JButton buttonFromCopy = null;
	JButton buttonToCopy = null;
	JButton buttonCopy = null;
	
	int fileSize = 0;
	float currentFileSizePercent = 0;
	
	File fileFrom = null;
	File fileTo = null;
	
	boolean flg1 = false;
	boolean flg2 = false;
	
	Timer time = null;

	
	public static void main(String[] args) {
		DirCopy frame = new DirCopy();
		frame.setBounds(20, 20, 300, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	DirCopy() {
		JLabel label = new JLabel("Progress");
		label.setAlignmentX(0.5f);
		
		progress.setPreferredSize(new Dimension(10, 100));
		progress.setStringPainted(true);

		buttonFromCopy = new JButton("FromCopy");
		buttonFromCopy.addActionListener(this);
		buttonFromCopy.setActionCommand("FromCopy");
		buttonFromCopy.setAlignmentY(0.5f);

		buttonToCopy = new JButton("ToCopy");
		buttonToCopy.setActionCommand("ToCopy");
		buttonToCopy.addActionListener(this);
		buttonToCopy.setAlignmentY(0.5f);
		
		buttonCopy = new JButton("COPY");
		buttonCopy.setEnabled(false);
		buttonCopy.setActionCommand("copy");
		buttonCopy.addActionListener(this);

		JButton buttonClose = new JButton("close");
		buttonClose.setAlignmentX(0.5f);
		buttonClose.setActionCommand("close");
		buttonClose.addActionListener(this);

		JPanel panel1 = new JPanel();
		JPanel panel2 = new JPanel();
		JPanel panel3 = new JPanel();
		panel1.setLayout(new BoxLayout(panel1, BoxLayout.Y_AXIS));
		panel2.setLayout(new BoxLayout(panel2, BoxLayout.LINE_AXIS));
		panel3.setLayout(new BoxLayout(panel3, BoxLayout.Y_AXIS));
		panel1.add(label);
		panel1.add(progress);
		panel2.add(buttonFromCopy);
		panel2.add(buttonToCopy);
		panel2.add(buttonCopy);
		panel3.add(buttonClose);

		getContentPane().add(panel1, BorderLayout.PAGE_START);
		getContentPane().add(panel2, BorderLayout.CENTER);
		getContentPane().add(panel3, BorderLayout.PAGE_END);

	}
	
	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getActionCommand().equals("time")) {
			if (currentFileSizePercent < 100) {
				progress.setValue((int)currentFileSizePercent);
				progress.setString("CONTINUE");
			} else {
				progress.setValue((int)currentFileSizePercent);
				progress.setString("COMPLETE");
				time.stop();
			}
		}
		// CloseButton action
		if (e.getActionCommand().equals("close")) {
			System.exit(0);
		}
		// closeButton action
		if (e.getActionCommand().equals("FromCopy")) {
			JFileChooser fChooser = new JFileChooser();
			//Directory Only Select
			fChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			int select = fChooser.showOpenDialog(this);
			if(select == JFileChooser.APPROVE_OPTION) {
				fileFrom = fChooser.getSelectedFile();
				fileSize = (int) getFileSize(fileFrom);
				flg1 = true;
				// COPYButton activation
				if (flg2) buttonCopy.setEnabled(true);
			}
		}
		
		// ToCopy Button action
		if (e.getActionCommand().equals("ToCopy")) {
			JFileChooser fChooser = new JFileChooser();
			//Directory Only Select
			fChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			int select = fChooser.showOpenDialog(this);
			if (select == JFileChooser.APPROVE_OPTION) {
				fileTo = fChooser.getSelectedFile();
				flg2 = true;
				// COPYButton activation
				if (flg1) buttonCopy.setEnabled(true); 
			}
		}
		
		// COPYButton activation
		if(e.getActionCommand().equals("copy")) {
			File dir = new File(fileTo.getPath() + "/" + fileFrom.getName());
			if(dir.isDirectory() && dir.exists()) {
				dirDelete(dir);
			}
			time = new Timer(1000, this);
			time.setActionCommand("time");
			time.start();
			FileCopy fileCopy = new FileCopy();
			// fileCopy
			fileCopy.execute();
		}
	}
	
	
	/**
	 * get directory file size
	 * @param dir directory
	 * @return file size
	 */
	private long getFileSize(File dir) {
		long size = 0;
		File[] fileList = dir.listFiles();
		if(fileList != null) {
			for(File file : fileList) {
				if(file.isFile()) {
					size += file.length();
				} else {
					size += getFileSize(file);
				}
			}
		}
		
		return size;
	}
	
	/**
	 * copy from dirFrom to dirTo 
	 * @param dirFrom
	 * @param dirTo
	 */
	private void fileCopy(File dirFrom, File dirTo) {		
		File[] fromFile = dirFrom.listFiles();
		dirTo = new File(dirTo.getPath() + "/" + dirFrom.getName());
		dirTo.mkdir();

		if(fromFile != null) {
			for(File f : fromFile) {
				// if file
				if (f.isFile()) {
					copy(f, dirTo);
				// if directory
				} else {
					fileCopy(f, dirTo);
				}
			}
		}
	}
	
	/**
	 * copy from file to directory
	 * @param file
	 * @param dir
	 */
	private void copy(File file, File dir) {
		
		File copyFile = new File(dir.getPath() + "/" + file.getName());
		
		try {
			
			copyFile.createNewFile();
			
			FileChannel channelFrom = new FileInputStream(file).getChannel();
			FileChannel channelTo = new FileOutputStream(copyFile).getChannel();
			
			try {
				//file copy
				channelFrom.transferTo(0, channelFrom.size(), channelTo);
				float currentFileSize = getFileSize(new File(fileTo.getPath() + "/" + fileFrom.getName()));
				//calculate Progress
				currentFileSizePercent = (float) (currentFileSize / fileSize) * 100;
			
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				channelFrom.close();
				channelTo.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}
	
	/**
	 * delete directory
	 * @param dir
	 */
	private void dirDelete(File dir) {
		for (File f : dir.listFiles()) {
			if (f.isFile()) {
				f.delete();
			} else {
				dirDelete(f);
				f.delete();
			}	
		}
		dir.delete();
	}
	/**
	 * copy directory
	 */
	class FileCopy extends SwingWorker<Object, Object> {
		@Override
		public Object doInBackground() {
			fileCopy(fileFrom, fileTo);
			return null;
		}
	}
}
