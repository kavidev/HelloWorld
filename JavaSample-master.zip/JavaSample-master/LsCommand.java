import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class LsCommand {

	public static void main(String[] args) {
		File f = new File(".");
		if(args.length == 0) {
			for(File f1 : f.listFiles()) {
				if(!f1.getName().substring(0,1).equals(".")){
					System.out.println(f1.getName());
				}
			}
		} else if("-l".equals(args[0])) {
			for(File f1 : f.listFiles()) {
				if(!f1.getName().substring(0,1).equals(".")){
					printDirectoryContent(f1);
				}
			}
		} else if("-la".equals(args[0])) {
			for(File f1 : f.listFiles()) {
				printDirectoryContent(f1);
			}
		} else if("-lS".equals(args[0])) {
			File[] file = f.listFiles();
			sortFileSize(file);
			for(File f1 : file) {
				printDirectoryContent(f1);
			}
		} else {
			System.out.println("argument is mistake");
		}
	}
	
	private static String makeDate(File f) {
		Date date = new Date(f.lastModified());
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		return format.format(date);
	}
	
	private static void printDirectoryContent(File f) {
		System.out.printf("%s%s%s%s %8d %s %s\n",(f.isFile() ? 'f' : 'd')
				, (f.canExecute() ? 'x' : '-'), (f.canWrite() ? 'w' : '-')
				,(f.canRead() ? 'r' : '-'), f.length(), makeDate(f)
		, f.getName());
		
	}
	
	private static void sortFileSize(File[] file) {
		for(int i=1; i<file.length; i++) {
			File tmpFile = file[i];
			int j = i-1;
			while(j>=0 && tmpFile.length()<file[j].length()) {
				file[j+1] = file[j];
				--j;
			}
			file[j+1] = tmpFile;
		}
		
	}

}
