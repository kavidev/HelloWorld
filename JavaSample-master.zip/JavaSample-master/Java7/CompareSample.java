package Java7;

public class CompareSample {

	public static void main(String[] srgs) {
		CompareSample cs = new CompareSample();
		cs.compare(2, 1);
		cs.compare(1, 2);
		cs.compare(1, 1);
	}

	private void compare(int a, int b) {
		if (Integer.compare(a, b) > 0) {
			System.out.println("a is high");
		} else if (Integer.compare(a, b) < 0) {
			System.out.println("b is high");
		} else {
			System.out.println("equals");
		}
	}
}
