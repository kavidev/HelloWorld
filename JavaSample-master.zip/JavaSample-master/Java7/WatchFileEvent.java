package Java7;

import java.nio.file.*;

public class WatchFileEvent {
	public static void main(String[] args) throws Exception {
		FileSystem fileSystem = FileSystems.getDefault();
		WatchService watchService = fileSystem.newWatchService();

		Path path = Paths.get("/home/user1");

		WatchEvent.Kind<?>[] events = {
			StandardWatchEventKinds.ENTRY_CREATE,
			StandardWatchEventKinds.ENTRY_DELETE
		};
		path.register(watchService, events);

		while(true) {
			System.out.println("Watching Event...\n");

			WatchKey watchKey = watchService.take();
			if (watchKey.isValid()) {
				for (WatchEvent<?> event : watchKey.pollEvents()) {
					if (event.kind().name().equals("ENTRY_CREATE")) {
						System.out.println(event.context() + " is created\n");
					}
					if (event.kind().name().equals("ENTRY_DELETE")) {
						System.out.println(event.context() + " is deleted\n");
					}
				}
			}
			watchKey.reset();
		}
	}
}
