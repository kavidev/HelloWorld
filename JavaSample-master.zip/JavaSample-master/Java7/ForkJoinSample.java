package Java7;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

public class ForkJoinSample {
	
	class Sum extends RecursiveTask<Long> {
		private int start;
		private int end;

		public Sum(int start, int end) {
			this.start = start;
			this.end = end;
		}

		@Override
		protected Long compute() {
			long sum = 0;
			
			if (end - start < 10) {
				for (int i = start; i <= end; i++) {
					sum += i;
				}
				
				return sum;				
			} else {
				int middle = start + (end - start) / 2;
				Sum sum1 = new Sum(start, middle);
				Sum sum2 = new Sum(middle + 1, end);
				sum1.fork();
				sum+=sum2.compute();
				sum+=sum1.join();
				
				return sum;
			}
		}
		
	}
	
	public static void main(String[] args) {
		ForkJoinSample forkJoinSample = new ForkJoinSample();
		int start = 1;
		int end = 22;
		Sum sum = forkJoinSample.new Sum(start,end);
		
		ForkJoinPool forkJoinPool = new ForkJoinPool();
		long result = forkJoinPool.invoke(sum);
		System.out.println(result);
	}
}