package Java7;
import java.beans.Expression;
public class JavaBeansSample {
	public static void main(String[] args) throws Exception {
		Profile p1 = new Profile("name1", "22");		
		Expression expression = new Expression(p1, "setName", new String[]{ "name3" });
		expression.execute();
		expression = new Expression(p1, "setAge", new String[]{ "25" });
		expression.execute();
		System.out.println(p1);
	}
}
