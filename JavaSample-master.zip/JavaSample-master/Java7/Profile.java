package Java7;
public class Profile {
	private String name = null;
	private String age = null;
	
	Profile(String name, String age) {
		this.name = name;
		this.age = age;
	}

	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return this.name;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getAge() {
		return this.age;
	}

	@Override
	public String toString() {
		return name + " : " + age;
	}
}
