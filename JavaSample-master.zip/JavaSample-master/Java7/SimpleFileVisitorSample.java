package Java7;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;

public class SimpleFileVisitorSample extends SimpleFileVisitor<Path> {
	public static void main(String[] args) throws IOException {
		Path path = Paths.get(System.getProperty("user.home") +"/test");
		Files.walkFileTree(path, new SimpleFileVisitorSample());
	}

	@Override
	public FileVisitResult postVisitDirectory(Path path, IOException ioException) throws IOException{
		if (ioException == null) {
			Files.delete(path);
			return FileVisitResult.CONTINUE;
		} else {
			throw ioException;
		}
	}
	
	@Override
	public FileVisitResult visitFile(Path path, BasicFileAttributes attrs) throws IOException {
		Files.delete(path);
		return FileVisitResult.CONTINUE;
	}

}
