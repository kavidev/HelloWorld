package Java7;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.Map;

public class FileStatus {
	public static void main(String[] args) throws IOException {
		Path path = FileSystems.getDefault().getPath("/home");
		Map<String, Object> map = Files.readAttributes(path, "*");
		Iterator<String> iterator = map.keySet().iterator();
		
		while(iterator.hasNext()) {
			String attr = iterator.next();
			System.out.println(attr + ":" + Files.getAttribute(path, attr));
		}
	}
}
