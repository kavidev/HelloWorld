package Java7;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class FileReadUsingFiles {

	public static void main(String[] args) throws IOException {

		Path path = Paths.get(System.getProperty("user.home")
				+ System.getProperty("file.separator") + "test.txt");
		byte[] bytedatas = Files.readAllBytes(path);
		for (byte data : bytedatas) {
			System.out.print((char) data);
		}

		System.out.println("");
		List<String> dataList = Files.readAllLines(path,
				Charset.forName("UTF-8"));

		for (String data : dataList) {
			System.out.println(data);
		}

	}
}
