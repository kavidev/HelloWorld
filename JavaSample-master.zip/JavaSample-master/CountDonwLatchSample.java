import java.util.concurrent.CountDownLatch;

public class CountDonwLatchSample {
	final private CountDownLatch start = new CountDownLatch(1);
	final private CountDownLatch end = new CountDownLatch(2);
	final static private StringBuffer str = new StringBuffer();

	public static void main(String[] args) {
		new CountDonwLatchSample().start();
	}
	
	private void start() {
		ThreadA threadA = new CountDonwLatchSample().new ThreadA();
		Thread thread = new Thread(threadA);
		thread.start();
		thread = new Thread(threadA);
		thread.start();
		new CountDonwLatchSample().initialize();
		try {
			end.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(str.append("end"));
		
	}
	
	private void initialize() {
		str.append("start");
		start.countDown();
	}
	
	class ThreadA implements Runnable{

		@Override
		public void run() {
			try {
				start.await();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			str.append(" " + Thread.currentThread().getName() + " ");
			end.countDown();
		}
		
	}
}
