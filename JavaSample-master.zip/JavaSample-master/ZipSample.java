import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;



public class ZipSample {

	/**
	 * @param args
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args){
		ZipOutputStream output = null;
		try{
			// zip name
			File zipFile = new File("Sample.zip");
			// directory name
			File[] files = {new File("zipSample1"),new File("zipSample2")};
			output = new ZipOutputStream(new FileOutputStream(zipFile));
			// create zip
			makeZipFile(output,files);
			output.finish();
			output.close();
		} catch(Exception e){
			e.printStackTrace();
		}
	}
	private static void makeZipFile(ZipOutputStream output,File[] files) throws IOException{
		for(File file : files){
			if(file.isDirectory()){
				makeZipFile(output,file.listFiles());
			}else{
				ZipEntry zEntry = new ZipEntry(file.getPath());
				output.putNextEntry(zEntry);
				InputStream input = new BufferedInputStream(new FileInputStream(file));
				byte[] buf = new byte[1024];
				for(;;){
					int len = input.read(buf);
					if(len==-1) break;
					output.write(buf,0,len);
				}
				input.close();		
			}
		}
	}
}
