import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

/**
 * CalendarApp
 */
public class CalendarApp extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private String[] columnNames = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri",
			"Sat" };
	private Integer[][] rowData = new Integer[6][7];
	private Container container = null;
	private JLabel label = null;
	private int month = 0;
	private int year = 0;
	private Calendar calendar = Calendar.getInstance();
	private static CalendarApp frame = new CalendarApp();
	private JTable table = null;
	JPanel panel2 = new JPanel();

	public static void main(String[] args) {
		start();
	}

	/**
	 * 
	 */
	private static void start() {
		frame.setBounds(100, 100, 500, 500);
		frame.setTitle("Calendar");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
	}

	/**
	 * 
	 */
	public CalendarApp() {
		initCalendar();
		table = new JTable(rowData, columnNames);
		table.setEnabled(false);
		table.setPreferredScrollableViewportSize(new Dimension(100, 100));

		JButton button = new JButton("close");
		button.setActionCommand("close");
		button.addActionListener(this);

		JButton preMonth = new JButton("pre");
		preMonth.setActionCommand("pre");
		preMonth.addActionListener(this);

		JButton nextMonth = new JButton("next");
		nextMonth.setActionCommand("next");
		nextMonth.addActionListener(this);

		JPanel panel1 = new JPanel();
		panel1.setLayout(new FlowLayout());
		panel1.add(preMonth);
		panel1.add(button);
		panel1.add(nextMonth);

		panel2 = new JPanel();
		panel2.setLayout(new BoxLayout(panel2, BoxLayout.PAGE_AXIS));
		// panel2.setPreferredSize(new Dimension(500, 200));
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setPreferredSize(new Dimension(500, 160));
		year = calendar.get(Calendar.YEAR);
		month = calendar.get(Calendar.MONTH) + 1;
		StringBuffer strMonth = new StringBuffer(Integer.valueOf(month)
				.toString());
		if (strMonth.length() == 1) {
			strMonth.insert(0, "0");
		}
		label = new JLabel("Calendar " + new Integer(year).toString() + "/"
				+ strMonth);
		label.setAlignmentX(0.0f);
		panel2.add(label, BorderLayout.PAGE_START);
		panel2.add(scrollPane);

		container = getContentPane();
		container.add(panel2, BorderLayout.PAGE_START);
		container.add(panel1, BorderLayout.PAGE_END);
	}

	/**
	 * 
	 */
	private void initCalendar() {
		month = calendar.get(Calendar.MONTH);
		int maxDay = calendar.getMaximum(Calendar.DATE);
		calendar.set(Calendar.DATE, 1);
		int firstYobi = calendar.get(Calendar.DAY_OF_WEEK);
		setRowData(maxDay, firstYobi);
	}

	/**
	 * calendar data set
	 * @param maxDay
	 * @param yobi
	 */
	private void setRowData(int maxDay, int yobi) {
		initRowData();
		int i = 0;
		int j = yobi - 1;
		int k = 0;
		while (i++ < maxDay) {
			rowData[k][j++] = i;
			if (j == rowData[k].length) {
				j = 0;
				++k;
			}
		}

	}

	/**
	 * set calendar data null
	 */
	private void initRowData() {
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; ++j) {
				rowData[i][j] = null;
			}
		}
	}

	/* 
	 * button action
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// close button action
		if ("close".equals(e.getActionCommand())) {
			System.exit(0);
		}
		// pre button action
		if ("pre".equals(e.getActionCommand())) {			
			if (--month == 0) {
				--year;
				month = 12;
			}
			StringBuffer strMonth = new StringBuffer(Integer.valueOf(month)
					.toString());
			if (strMonth.length() == 1) {
				strMonth.insert(0, "0");
			}
			calendar.set(Calendar.MONTH, month);
			setRowData(calendar.getMaximum(Calendar.DATE),
					calendar.get(Calendar.DAY_OF_WEEK));
			label.setText("Calendar " + new Integer(year).toString() + "/"
					+ strMonth);
			container.add(panel2, BorderLayout.PAGE_START);
			frame.pack();
			frame.setVisible(true);
		}
		// next button action
		if ("next".equals(e.getActionCommand())) {
			if (++month == 13) {
				++year;
				month = 1;
			}
			StringBuffer strMonth = new StringBuffer(Integer.valueOf(month)
					.toString());
			if (strMonth.length() == 1) {
				strMonth.insert(0, "0");
			}
			calendar.set(Calendar.MONTH, month);
			setRowData(calendar.getMaximum(Calendar.DATE),
					calendar.get(Calendar.DAY_OF_WEEK));
			label.setText("Calendar " + new Integer(year).toString() + "/"
					+ strMonth);
			container.add(panel2, BorderLayout.PAGE_START);
			frame.pack();
			frame.setVisible(true);
		}
	}
}
