import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.UnsupportedEncodingException;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


public class FileViewer extends JFrame implements ActionListener{

	JTextArea area = null;

	public static void main(String[] args) {
		FileViewer frame = new FileViewer();
		frame.setBounds(30, 30, 400, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	FileViewer() {
	    area = new JTextArea(15, 1);
		area.setEditable(false);
		area.setLineWrap(true);
		JScrollPane scroll = new JScrollPane(area);
		JButton button = new JButton("folderSelect");
		button.addActionListener(this);
		getContentPane().add(scroll, BorderLayout.PAGE_START);
		getContentPane().add(button, BorderLayout.PAGE_END);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JFileChooser chooser = new JFileChooser();
		chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		int select = chooser.showOpenDialog(this);
		if(select == JFileChooser.APPROVE_OPTION) {
			File dir = chooser.getSelectedFile();
			for(File file : dir.listFiles()) {
				area.append("�E"+file.getPath() + "\n");
			}
		} 
	}
	

}
