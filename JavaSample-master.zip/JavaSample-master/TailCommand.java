import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;


public class TailCommand {
	
	private static int line = 10;
	
	private static BufferedReader input = null;
	
	public static void main(String[] args) throws IOException {
		
		try {
		
			if(args.length == 0 || args.length >= 3) {System.out.println("TailCommand [option] file"); System.exit(0);}
			File f = null;
			
			if(args.length == 1) {
				f = new File(args[0]);
			} else {
				f = new File(args[1]);
			}
			
			if(!f.exists()) { System.out.println("file doesn't exist"); System.exit(0); }
			
			input = new BufferedReader(new FileReader(f));
			String[] str1 = new String[line];
			String[] str2 = new String[line];
			String str = input.readLine();
			int i = 0;
			int readLineNo = 0;	
			while(str != null) {
				str1[i++] = str;
				if(i == line) { i = 0; str2 = str1; str1 = new String[line]; }
				str = input.readLine();
				++readLineNo;
			}
			
			int n = 0;
			while(str1[n] != null) {
				++n;
			}

			if(n!=0) {
				if(n == line) {
					
					for(String a : str2) {
						System.out.println(a);
					}
				
				} else {
					
					for(int j=n; j<line; ++j) {
						System.out.println(str2[j]);
					}
				
				}
			}

			for(String a : str1) {
				if(a == null) break;
				System.out.println(a);
			}
			
			if("-f".equals(args[0])) {
				showFile(f, readLineNo);
			}
		
		} finally {
			if(input != null) input.close();
		}
	}
	
	public static void showFile(File file, int readLineNo) {
		
		long size = file.length();
		
		while(true) {
			
			try {
			
			if(size < file.length()) {
				int i=0;
				String str = input.readLine();
				++i;

				while(str != null){
					if(i >= readLineNo) {
						System.out.println(str);
						++readLineNo;
					}
					str = input.readLine();
					++i;
				}
			}
			
			size = file.length();
			input.close();
			Thread.sleep(5000);
			input = new BufferedReader(new FileReader(file));
			
			} catch (InterruptedException | IOException e) {
				e.printStackTrace();
			}
		}
	}
}
