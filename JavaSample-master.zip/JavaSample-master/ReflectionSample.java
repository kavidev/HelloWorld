import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Calendar;


public class ReflectionSample {
	/**
	 * @param args
	 * @throws NoSuchFieldException 
	 * @throws SecurityException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 */
	public static void main(String[] args){
		try{
			accessFieldByReflection();
			accessMethodByReflection();
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * @throws SecurityException
	 * @throws NoSuchFieldException
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	private static void accessFieldByReflection() throws SecurityException, NoSuchFieldException
	, IllegalArgumentException, IllegalAccessException{
		Profile pro = new Profile();
		Class<Profile> cal = Profile.class;
		// access field
		Field fieldName = cal.getDeclaredField("name");
		Field fieldAge = cal.getDeclaredField("age");
		String name = (String)fieldName.get(pro);
		String age = (String)fieldAge.get(pro);
		System.out.println(name);
		System.out.println(age);
		// change field
		fieldName.set(pro, "name1");
		fieldAge.set(pro, "23");
		System.out.println(fieldName.get(pro));
		System.out.println(fieldAge.get(pro));
		
	}

	private static void accessMethodByReflection() throws SecurityException, NoSuchMethodException
	, IllegalArgumentException, IllegalAccessException, InvocationTargetException{
		Profile pro = new Profile();
		Class[] type = new Class[] { String.class,String.class };
		Method method = pro.getClass().getMethod("setProfile", type);
		// invoke setProfile
		method.invoke(pro ,"Yasunaga2" ,"27");
		type = new Class[] {};
		method = pro.getClass().getMethod("showProfile", type);
		// invoke showProfile
		method.invoke(pro, new Object[0]);
		
	}
}

class Profile{
	public String name = "Yasunaga1";
	public String age = "26";
	public void showProfile(){
		System.out.println("name:" + name);
		System.out.println("age:" + age);
	}
	
	public void setProfile(String name,String age){
		this.name = name;
		this.age = age;
	}
}