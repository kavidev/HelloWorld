package jsonicsample;

import net.arnx.jsonic.*;
import java.io.*;
import java.util.*;
public class ChangeJson {
	
	public static void main(String[] args) {
		
		try {
			List<String> list = new ArrayList<String>();
			list.add("aaa");
			list.add("bbb");

			Map<String, String> map = new HashMap<String, String>();
			map.put("aaaa", "AAAA");
			map.put("bbbb", "BBBB");

			JSON.encode(new Test("a", new String[] {"aa", "bb"}, list, map), new FileWriter("json.txt"));
		} catch (IOException ie) {
			ie.printStackTrace();
		}
	}
}

