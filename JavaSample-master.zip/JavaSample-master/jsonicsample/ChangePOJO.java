package jsonicsample;

import net.arnx.jsonic.*;
import java.util.*;
public class ChangePOJO {

	public static void main(String[] args) {
		String json = "{ value : \"value1\", values : [\"value1\", \"value2\"], valueList : [\"value111\", \"value222\"], valueMap : { \"key1\" : \"value1\", \"key2\" : \"value2\"} }";	
		Test1 test = JSON.decode(json, Test1.class);
		System.out.println(test);
	}

	static class Test1 {
		private String value;
	
		private String[] values;
		
		private List<String> valueList;
		
		private Map<String, String> valueMap;

		public void setValue(String value) {
			this.value = value;
		}
		
		public void setValues(String[] values) {
			this.values = values;
		}
		
		public void setValueList(List<String> list) {
			this.valueList = list;
		}

		public void setValueMap(Map<String, String> map) {
			this.valueMap = map;
		}
		
		@Override
		public String toString() {
			StringBuilder valuesSb = new StringBuilder("[");
			
			for (String str : this.values) {
				valuesSb.append(str);
				valuesSb.append(",");
			}
	
			String str1 = valuesSb.substring(0, valuesSb.length() - 1);
			str1 = str1.concat("]");
		
			StringBuilder valueListSb = new StringBuilder("[");
			for (String str : this.valueList) {
				valueListSb.append(str);
				valueListSb.append(",");
			}
			String str2 = valueListSb.substring(0, valueListSb.length() - 1);
			str2 = str2.concat("]");
			
			StringBuilder valueMapSb = new StringBuilder("{");
			for (Map.Entry<String, String> entry : valueMap.entrySet()) {
				String key = entry.getKey();
				String value = entry.getValue();
				valueMapSb.append(key);
				valueMapSb.append(":");
				valueMapSb.append(value);
				valueMapSb.append(",");
			}
			String str3 = valueMapSb.substring(0, valueMapSb.length() - 1);
			str3 = str3.concat("}");

			return "value:" + value + " values:" + str1 + " valueList:" + str2 + " valueMap:" + str3;
		}
	}
}
