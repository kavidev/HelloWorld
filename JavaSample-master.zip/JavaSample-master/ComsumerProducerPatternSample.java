import java.io.IOException;
import java.io.InputStream;
import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ComsumerProducerPatternSample {

	public static void main(String[] args) throws IOException {
		BlockingQueue<String> queue = new ArrayBlockingQueue<>(3);
		new Thread(new Producer(queue)).start();
		new Thread(new Comsumer(queue)).start();
	}

	static class Producer implements Runnable{
		Queue<String> queue;

		Producer(Queue<String> queue) {
			this.queue = queue;
		}

		private void producer() {
			while (true) {
				InputStream stream = System.in;
				byte[] b = new byte[255];
				try {
					stream.read(b);
					((BlockingQueue<String>) queue).put(new String(b));
					System.out.println(Thread.currentThread().getName() + " produce task");
				} catch (IOException e) {
					e.printStackTrace();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		@Override
		public void run() {
			producer();
		}

	}
	static class Comsumer implements Runnable{
		Queue<String> queue;

		Comsumer(Queue<String> queue) {
			this.queue = queue;
		}

		private void comsumer() {
			while (true) {
				try {
					String a = ((BlockingQueue<String>) queue).take();
					System.out.println(a.toUpperCase());
					System.out.println(Thread.currentThread().getName() + " comsumer task");
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
			}
			
		}

		@Override
		public void run() {
			comsumer();
		}		
	}
}
