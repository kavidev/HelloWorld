package designpattern;

public class BuilderMain {
	public static void main(String[] args) {
		Mail mail = new MornigMail();
		Builder builder = new Builder(mail);
		builder.constract();
		System.out.println(mail.getMail());
	}
}

class Builder {
	private Mail mail;

	public Builder(Mail mail) {
		this.mail = mail;
	}

	public void constract() {
		mail.makeDestination("test@test.co.jp");
		mail.makeSubject("subject1");
		mail.makeBody("aaaaaaa\nbbbbbb\ncccccc");
	}
}

abstract class Mail {
	protected StringBuilder mail = new StringBuilder();

	public void makeDestination(String mailAddress) {
		mail.append("TO:" + mailAddress);
		mail.append("\n");
		mail.append("\n");
	}

	abstract void makeSubject(String subject);

	abstract void makeBody(String body);
	
	public String getMail() {
		return this.mail.toString();
	}
}

class MornigMail extends Mail {

	@Override
	void makeSubject(String subject) {
		mail.append("subject:");
		mail.append(subject);
		mail.append("\n");
	}

	@Override
	void makeBody(String body) {
		mail.append("-------------------------------\n");
		mail.append("Good morning\n");
		mail.append(body);
		mail.append("\n");
		mail.append("-------------------------------");
	}

}