package designpattern.adapter;

import java.util.Properties;
import java.io.*;

public class FileProperties extends Properties implements FileIO {
	private Properties p = null;

	public FileProperties() {
		p = new Properties();
	}

	@Override
	public void readFromFile(String filename) throws IOException {
		p.load(new FileInputStream(filename));
	}
	
	@Override
	public void writeToFile(String filename) throws IOException {
		p.store(new FileOutputStream(filename), "");				
	}

	@Override
	public void setValue(String key, String value) {
		p.setProperty(key, value);	
	}

	@Override
	public String getValue(String key) {
		return p.getProperty(key);
	}
	
}
