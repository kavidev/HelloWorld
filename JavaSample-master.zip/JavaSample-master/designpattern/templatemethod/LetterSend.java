package designpattern.templatemethod;

public class LetterSend extends MessageSend{

	protected LetterSend(String m, String n, String ｄ) {
		super(m, n, ｄ);
	}

	@Override
	public void makeBody(String name, String message) {
		
	}

	@Override
	public void send(String destination) {
		
	}

}
