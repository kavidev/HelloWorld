package designpattern.templatemethod;

public class MailSend extends MessageSend{

	protected MailSend(String message, String name, String ｄestination) {
		super(message, name, ｄestination);
	}

	@Override
	public void makeBody(String name, String message) {
		String content = name + "\n\n" + message;
		super.setContent(content);
	}
	
	@Override
	public void send(String destination) {
		System.out.println("Destination:" + destination + " sendMail");
		System.out.println("Message:" + super.getMessage());
	}

}
