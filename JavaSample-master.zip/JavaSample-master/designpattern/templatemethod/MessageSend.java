package designpattern.templatemethod;

abstract class MessageSend {
	
	public abstract void makeBody(String name, String message);

	public abstract void send(String destination);

	private String message;
	private String name;
	private String destination;
	private String content;
	
	public String getContent() {
		return content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}

	protected MessageSend(String m, String n, String ｄ) {
		this.message = m;
		this.name = n;
		this.destination = ｄ;
	}

	public void sendMessage() {
		makeBody(name, message);
		send(destination);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
