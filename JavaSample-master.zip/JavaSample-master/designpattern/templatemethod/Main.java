package designpattern.templatemethod;

public class Main {
	public static void main(String[] args) {
		MessageSend messageSend = new MailSend("hello", "Yasunaga1", "Yasunaga1@test.co.jp");
		messageSend.sendMessage();
	}
}
