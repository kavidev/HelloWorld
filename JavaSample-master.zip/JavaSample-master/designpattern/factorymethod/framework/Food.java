package designpattern.factorymethod.framework;
public abstract class Food {
	public abstract void eat();	
}
