package designpattern.factorymethod.framework;

public abstract class Kitchen {
	public final Food cook() {
		Food food = cookFood();
		return food;
	}

	public abstract Food cookFood();
}
