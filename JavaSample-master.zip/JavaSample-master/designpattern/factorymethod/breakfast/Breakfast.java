package designpattern.factorymethod.breakfast;

import designpattern.factorymethod.framework.*;

public class Breakfast extends Food {
	
	@Override
	public void eat() {
		System.out.println("delicious!!");
	}
}
