package designpattern.factorymethod.breakfast;

import designpattern.factorymethod.framework.Kitchen;

public class BreakfastKitchen extends Kitchen {

	@Override
	public Breakfast cookFood() {
		return new Breakfast();
	}
}