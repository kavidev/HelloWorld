package designpattern.factorymethod;

import designpattern.factorymethod.breakfast.BreakfastKitchen;
import designpattern.factorymethod.framework.Food;
import designpattern.factorymethod.framework.Kitchen;

public class Main {
	public static void main(String[] args) {
		Kitchen kitchen = new BreakfastKitchen();
		Food breakfast = kitchen.cook();
		breakfast.eat();
	}
}
