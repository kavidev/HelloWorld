import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class CyclicBarrierSample {

	private CyclicBarrier cyclicBarrier;
	private static List<Integer> sumList = new ArrayList<>();

	public static void main(String[] args) {
		int partition = Integer.parseInt(args[0]);
		int n = Integer.parseInt(args[1]);
		new CyclicBarrierSample().start(partition, n);
	}

	private void start(final int partition, final int n) {
		cyclicBarrier = new CyclicBarrier(partition, new Runnable() {

			@Override
			public void run() {
				int sums = 0;
				for (int sum : sumList) {
					sums += sum;
				}
				for (int i = 1; i < partition; i++) {
					sums -= i * n / partition;
				}
				System.out.println("sum:" + sums);
			}
		});

		for (int i = 0; i < partition; i++) {
			Count count = new Count(n * i / partition, n * (i + 1) / partition);
			Thread thread = new Thread(count);
			thread.start();
		}
	}

	class Count implements Runnable {

		int start;
		int end;

		Count(int start, int end) {
			this.start = start;
			this.end = end;
		}

		@Override
		public void run() {
			int sum = 0;
			for (int i = start; i <= end; i++) {
				sum += i;
			}

			CyclicBarrierSample.sumList.add(sum);
			try {
				System.out.println(Thread.currentThread().getName()
						+ " arrives");
				cyclicBarrier.await();
			} catch (InterruptedException | BrokenBarrierException e) {
				e.printStackTrace();
			}

			System.out.println(Thread.currentThread().getName() + " ends");
		}

	}
}
