import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

public class MysqlClient extends JFrame {

	static JTextField url = new JTextField(30);
	static Container container;
	static JTabbedPane tabbedPane;

	public static void main(String[] args) {
		MysqlClient mysqlClient = new MysqlClient();
		mysqlClient.setBounds(100, 100, 500, 400);
		mysqlClient.setVisible(true);
		mysqlClient.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	public MysqlClient() {
		url = new JTextField(30);
		url.setMargin(new Insets(3, 3, 3, 3));
		url.setText("jdbc:mysql://localhost:3306/TEST");
		url.setSize(10, 10);
		
		JPanel panel1 = new JPanel();
		JLabel jLabel = new JLabel("url:");
		panel1.add(jLabel);
		panel1.add(url);
		
		JPanel panel = new JPanel();
		panel.add(panel1, BorderLayout.PAGE_START);
		JButton close = new JButton("close");
		close.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});

		JButton connect = new JButton("connect");
		connect.addActionListener(new ConnectListener());

		JPanel panel2 = new JPanel();
		panel2.add(connect);
		panel2.add(close);
		panel.add(panel2);
		
		tabbedPane = new JTabbedPane();
		tabbedPane.addTab("HOME", panel);
		
		container = getContentPane();
		container.add(tabbedPane, BorderLayout.CENTER);
	}

}

class ConnectListener implements ActionListener {
	static Connection con;
	static JTextField textField = new JTextField(30);
	static JPanel panel1;
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String url = MysqlClient.url.getText();
		JTabbedPane tabbedPane = MysqlClient.tabbedPane;

		try {
			con = DriverManager.getConnection(url, "root", "root");

			panel1 = new JPanel();
			JPanel panel2 = new JPanel();

			panel2.add(new JLabel("SQL:"));
			panel2.add(textField);
			panel1.add(panel2, BorderLayout.PAGE_START);
			
			JButton exec = new JButton("exec");
			exec.addActionListener(new ExecListener());
			JButton close = new JButton("close");
			
			close.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					System.exit(-1);
				}
			});
			
			JPanel panel3 = new JPanel();
			panel3.add(exec);
			panel3.add(close);
			panel1.add(panel3, BorderLayout.PAGE_END);
			
			tabbedPane.add("EDITOR", panel1);
			tabbedPane.setSelectedIndex(1);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
	}
}

class ExecListener implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		Connection con = ConnectListener.con;
		JPanel panel = ConnectListener.panel1;
		
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(ConnectListener.textField
					.getText());
			while (rs.next()) {
				System.out.println(rs.getInt(1) + rs.getString(2));
			}
		} catch (SQLException e1) {
			JLabel label = new JLabel(e1.getMessage());
			panel.add(label, BorderLayout.LINE_START);
		}
	}
}