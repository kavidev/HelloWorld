package Algorithm;

import java.util.Random;

public class CountSort 
{
	// max value
	static private int MAX = 10;
	// array length
	static private int ARRAY_LENGTH = 20;
	public static void main(String[] args) {
		int A[] = RandomArray(MAX, ARRAY_LENGTH);
		int B[] = new int[MAX];
		for (int i=0; i<ARRAY_LENGTH; ++i) {
			++B[A[i]];
		}
		int idx = 0;
		for (int i=0; i<MAX; ++i) {
			while(B[i]-->0){
				A[idx++] = i;
			}
		}
		for (int a : A) {
			System.out.println(a);
		}
	}
	
	/**
	 * create random arrray. Its range is between 0 and max 
	 * @param max max value
	 * @param arrayLength array length
	 * @return random array 
	 */
	private static int[] RandomArray(int max, int arrayLength) {
		int A[] = new int[arrayLength]; 
		for (int i=0; i<arrayLength; ++i) {
			int a = (new Random().nextInt(max) % max);
			A[i] = a;
		}
		return A;
	}

}
