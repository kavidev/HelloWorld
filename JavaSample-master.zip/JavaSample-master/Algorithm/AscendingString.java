package Algorithm;

public class AscendingString {

	public static void main(String[] args) {
		String[] strs = {"book","color","apple","adress","block","city"};
		ascend(strs);
		for(String a : strs) {
			System.out.println(a);
		}
	}
	
	private static void ascend(String[] strs) {
		for(int i = 1; i < strs.length; ++i) {
			String tmp = strs[i];
			int j = i-1;
			while(j >= 0 && (compare(tmp, strs[j]))) {
				strs[j+1] = strs[j];
				--j;
			}
			strs[j+1] = tmp;
		}
	}
	
	private static boolean compare(String str1, String str2) {
		boolean result = false;
		char[] ch1 = str1.toCharArray();
		char[] ch2 = str2.toCharArray();
		int ch1i = 0;
		int ch2i = 0;
		while(true) {
			if(ch1[ch1i] > ch2[ch2i]) { result = false; break; }
			if(ch1[ch1i] < ch2[ch2i]) { result = true; break; }
			++ch1i;
			++ch2i;
		}
		
		return result;
	}

}
