package Algorithm;

public class PrimeNumber {

	public static void main(String[] args) {
		System.out.println(judge(19));
	}
	private static boolean judge(int number)
	{
		if (number <= 1 || number % 2 == 0) return false;
		for(int i=3; i<number;)
		{
			if(number%i == 0)
			{
				return false;
			}
			i = 2*i - 1;
		}
		return true;
	}

}
