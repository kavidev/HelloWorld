package Algorithm;

public class QuickSort {
	static int NO = 1000000;
	public static void main(String[] args) {
		int A[] = Util.makeRandom(NO);
		sort(A, 0, A.length - 1);
		for (int b : A) {
			System.out.println(b);
		}
	}

	public static void sort(int[] A, int left, int right) {
		if (left < right) {
			int p = partition(A, left, right);
			sort(A, left, p - 1);
			sort(A, p + 1, right);
		}
	}

	private static int partition(int[] A, int left, int right)
	{
		int p = A.length % (right - left) + left;
		Util.swap(A, right, p);
		
		int store = left;
		for(int i = left; i < right; i++)
		{
			if(A[i] <= A[right]){
				Util.swap(A, store, i);
				++store;
			}
		}
		Util.swap(A, store, right);
		return store;
	}
}
