package Algorithm;

public class BitArray {

	public static void main(String[] args) {
		Util.makeRandom(100);
	}

}
