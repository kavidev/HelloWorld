package Algorithm;

import java.util.ArrayList;

public class HashSearch {
	private static ArrayList<Integer>[] list = new ArrayList[10];

	public static void main(String[] args) {
		int[] A = Util.makeRandom(100);
		loadTable(A);
		Util.showArray(A);
		serch(20);
	}
	
	public static void loadTable(int[] A) {
		for(int i=0;i<10;++i) {
			list[i] = new ArrayList<>();
		}
		for (int i=0; i<A.length; ++i) {
			int hash = A[i] % 10;
			list[hash].add(A[i]);
		}
	}
	public static void serch(int target) {
		int hash = target % 5;
		for(int i=0;i<list[hash].size();++i) {
			if(list[hash].get(i) == target) {
				System.out.println("found");
				break;
			}
			if(i == list[hash].size() - 1) {
				System.out.println("not found");
			}
		}
	}
}
