package Algorithm;

public class BinarySearch {

	public static void main(String[] args) {
		int A[] = Util.makeRandom(150);
		InsertSort.sort(A);
//		Util.showArray(A);
		sort(A, 90);
		
	}
	
	public static void sort(int A[], int target) {
		boolean flg = true;
		int left = 0;
		int right = A.length - 1;
		int idx = 0;
		while(flg) {
			idx = (right - left) / 2;
			if(idx == 0) {
				System.out.println("not found");
				System.exit(0);
			}
			idx += left;
			if(A[idx] == target) {
				flg = false;
			} else if(A[idx] > target) {
				right = idx - 1;
			} else {
				left = idx + 1;
			}
		}
		System.out.println("target="+target);
		System.out.println("A["+idx+"]="+A[idx]);
	}

}
