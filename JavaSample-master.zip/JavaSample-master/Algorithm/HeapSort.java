package Algorithm;

public class HeapSort {
static int heapSize = 15;
/**
* @param args
*/
public static void main(String[] args) {
	int a[] = new int[100];
	a = Util.makeRandom(heapSize);
	showarray(a);
	System.out.println("");
	buildheap(a);
	for(int i = heapSize; i>0; --i){
		Util.swap(a, i-1, 0);
		--heapSize;
		heapify(a, 0, heapSize);
	}
	showarray(a);
	}
private static void showarray(int a[])
{
	for(int i=0;i<15;++i)
	{
		System.out.println("a["+i+"]="+a[i]);
	}
}

private static void buildheap(int[] a)
{
	for(int i = ((a.length) / 2 - 1); i >= 0; --i){
		heapify(a, i, heapSize);
	}
}

private static void heapify(int a[], int start, int max)
{
	int left = 2 * start + 1;
	int right = 2 * start + 2;
	int largest;
	if(left < max && (a[start] < a[left])){
		largest = left;
	} else{
		largest = start;
	}
	if(right < max && (a[right] > a[largest])){
		largest = right;
	}
	if(largest != start){
		Util.swap(a, start, largest);
		heapify(a, largest, max);
	}

}

}