package Algorithm;

import java.util.ArrayList;

public class BucketSort {
	private static int ARRAYLENGTH = 1000000;
	private static int MAX = 1000000;
	private static Bucket[] bucket = new Bucket[MAX/80];
	public static void main(String[] args) 
	{
		for(int i=0; i < MAX/80; ++i)
		{
			bucket[i] = new Bucket();
		}
		int A[] = Util.makeRandom1(ARRAYLENGTH, MAX);
		for(int i=0; i < A.length; ++i)
		{
			int hash = hash(A[i]);
			bucket[hash].add(A[i]);
		}
		extract(A);
		for(int a : A)
		{
			System.out.println(a);
		}
	}
	
	private static void extract(int[] A)
	{
		int j = 0;
		for(int i=0; i < bucket.length; ++i)
		{
			insertSort(bucket[i]);
			for(int k=0; k < bucket[i].getList().size(); ++k)
			{
				A[j] = bucket[i].getList().get(k);
				++j;
			}
		}
	}
	
	private static void insertSort( Bucket bucket )
	{
		ArrayList<Integer> list = bucket.getList();
		int no = list.size();
		for(int i=1; i<no; ++i)
		{
			int j = i;
			int tmp = list.get(j);
			while(j >= 1 && tmp < list.get(j-1))
			{
				list.set(j, list.get(j-1));
				--j;
			}
			list.set(j, tmp);
		}
	}
	
	private static int hash(int a)
	{
		return a/80;
	}
	
}

class Bucket 
{
	private ArrayList<Integer> list = new ArrayList<Integer>();
	public void add(Integer I)
	{
		list.add(I);
	}
	public int listSize()
	{
		return list.size();
	}
	public ArrayList<Integer> getList()
	{
		return list;
	}
}