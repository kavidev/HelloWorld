package Algorithm;

public class Inspection {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int A[] = Util.makeRandom(10000);
		QuickSort quick = new QuickSort();
		QuickSort.sort(A, 0, A.length - 1);
//		Util.showArray(A);
		long start = System.currentTimeMillis();
		BinarySearch.sort(A, 45);
		System.out.println(System.currentTimeMillis() - start);
		HashSearch.loadTable(A);
		start = System.currentTimeMillis();
		HashSearch.serch(45);
		System.out.println(System.currentTimeMillis() - start);
	}

}
