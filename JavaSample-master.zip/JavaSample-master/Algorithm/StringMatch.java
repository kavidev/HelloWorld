package Algorithm;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class StringMatch {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader(new File("XXXXXX/String.txt")));
		String str = reader.readLine();
		boolean result = false;
		while(str!=null)
		{
			result = match(str,"Hello");
			if(result) break;
			str = reader.readLine();
		}
		System.out.println(result);
	}
	private static boolean match(String str1,String str2)
	{
		boolean result = true;
		if(str1.length()<str2.length()) return false;
		char chr1[] = str1.toCharArray();
		char chr2[] = str2.toCharArray();
		for(int i=0;;++i){
			if(str1.length()-i<str2.length()) {
				result = false;
				break;
			}
			int k = i;
			for(int j=0;j<str2.length();++j)
			{
				if(chr2[j]!=chr1[k]) break;
				++k;
			}
			if(k==(str2.length())){
				result = true;
				break;
			}
				
		}
		return result;
		
	}

}
