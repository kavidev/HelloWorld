import java.util.Random;

public class medianSort {
	private static final int Length = 20;
	public static void main(String[] args) {
		int[] A = {};
		try {
		A = make(Length);
		mediamSort(A, 0, Length-1);
//		for(int a : A) {
//			System.out.println(a);
//		}
		} catch (Exception e) {
			for(int a : A) {
				System.out.println(a);
			}
		}
	}
	
	static void mediamSort(int[] A, int left, int right) throws Exception {
//System.out.println(left + " " + right);
		if (left >= right) {
			throw new Exception();
		} else {
			int med = (right-left+1) / 2;
			int me = selectKth(A, med+1, left, right);
//System.out.println(me);			
			mediamSort(A, left, left+me-1);
			mediamSort(A, left+me+1, right);
		} 
	}
	
	static int partition(int[] A, int left, int right, int pivotIndex) {
		int tmp = A[pivotIndex];
		A[pivotIndex] = A[right];
		A[right] = tmp;
		int store = left;
		for(int i=left; i<right; ++i) {
			if(A[i] <= A[right]) {
				int tmp1 = A[i];
				A[i] = A[store];
				A[store] = tmp1;
				++store;
			}
		}
		tmp = A[right];
		A[right] = A[store];
		A[store] = tmp;
		return store;
	}
	
	static int selectKth(int[] A, int m, int left, int right) {
		int idx = left;
		int p = partition(A, left, right, idx);
		if (left+m-1 == p) {
			return p;
		}
		if (left+m-1 < p) {
			return partition(A, m, left, p-1);
		} else {
			return partition(A, m - (p-left+1), p+1, right);
		}
	}
	static int[] make(int a) {
		int[] A = new int[a];
		for(int i=0; i<A.length; ++i) {
			A[i] = new Random().nextInt(a + 10);
		}
		return A;
	}

}
