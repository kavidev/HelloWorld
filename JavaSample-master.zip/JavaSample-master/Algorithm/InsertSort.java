package Algorithm;

public class InsertSort 
{
	static int NO = 10000;
	public static void main(String[] args) 
	{
		int[] A = Util.makeRandom(NO);
		sort(A);
		long end = System.currentTimeMillis();
		for(int a: A) 
		{
			System.out.println(a);
		}
	}
	
	public static void sort(int[] A)
	{
		for (int i=1; i<A.length; ++i)
		{
			int tmp = A[i];
			int j = i-1;
			while (j>=0 && tmp<A[j])
			{
				A[j+1] = A[j];
				--j;
			}
			A[j+1] = tmp;
		}
	}

}
