package Algorithm;

public class SquareRoot {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		method(3);
	}
	private static void method(int a)
	{
		int basic = 0;
		for(int i=1;i<a;++i)
		{
			if(a<i*i){
				basic = i - 1;
			}
		}
		float b = (float) (basic+0.0001);
		while(true)
		{
			
		}
	}

}
