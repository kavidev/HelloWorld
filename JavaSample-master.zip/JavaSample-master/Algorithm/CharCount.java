package Algorithm;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class CharCount {
	private static TreeMap<Character, Integer> map = new TreeMap<Character, Integer>();
	/**
	 * @param args
	 */
	public static void main(String[] args) {
//		String str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String str = "abcdefghijklmnopqrstuvwxyzABCDEFBBBBBBBBBBBBB";
		init();
		StringCheck(str);
		System.out.println(map);

	}
	private static void init()
	{
		for(int i=65;i<91;++i)
		{
			map.put(Character.valueOf((char)i), Integer.valueOf(0));
		}
		for(int i=97;i<123;++i)
		{
			map.put(Character.valueOf((char)i), Integer.valueOf(0));
		}
	}
	private static void StringCheck(String str)
	{
		char[] chr = str.toCharArray();
		for(int i=0;i<chr.length;++i)
		{
			if(map.containsKey(chr[i])){
				int a = map.get(chr[i])+1;
				map.put(chr[i], a);
			}
		}
	}

}
