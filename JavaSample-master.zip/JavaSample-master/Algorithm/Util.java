package Algorithm;

import java.util.Random;

public class Util {
	public static int[] makeRandom(int n)
	{
		Random random = new Random();
		int array[] = new int[n];
		for(int i=0; i<n; ++i)
		{
			array[i] = random.nextInt(n + 100);
		}
		return array;
	}

	public static int[] swap(int[] A, int b, int c)
	{
		int tmp = A[b];
		A[b] = A[c];
		A[c] = tmp;
		return A;
	}
	
	public static int[] makeRandom1(int arrayLength, int maxValue)
	{
		Random random = new Random();
		int A[] = new int[arrayLength];
		for(int i=0; i<arrayLength; ++i)
		{
			A[i] = random.nextInt(maxValue);
		}
		return A;
	}
	
	public static void showArray(int A[]) {
		for(int a : A) {
			System.out.println(a);
		}
	}
}
