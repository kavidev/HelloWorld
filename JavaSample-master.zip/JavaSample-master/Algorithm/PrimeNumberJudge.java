package Algorithm;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class PrimeNumberJudge {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ArrayList<Integer> list = PrimeNumber(111);
		Iterator<Integer> i = list.iterator();
		int sum = 10;
		while(i.hasNext())
		{
			sum+= i.next();
		}
		System.out.println(sum);
	}
	private static boolean judge(int number)
	{
		boolean result = true;
		for(int i=2; i<number-1; ++i)
		{
			if(number%i == 0){
				result = false;
				break;
			}
		}
		return result;
	}
	private static ArrayList<Integer> PrimeNumber(int number)
	{
		ArrayList<Integer> list = new ArrayList<Integer>();
		for(int i=2; i<number+1; ++i)
		{
			for(int j=2; j<i; ++j)
			{
				if(i%j == 0){
					break;
				}
				if(j == i-1)
				{
					list.add(i);
				}
			}
		}
		return list;
	}
}
