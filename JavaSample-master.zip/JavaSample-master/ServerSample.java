import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;


public class ServerSample implements Runnable
{
	private ServerSocket server;
	static private Socket socket;
	public static void main(String[] args) 
	{
		new ServerSample().start();
	}
	
	private void start()
	{
		try {
			server = new ServerSocket(9999);
			while(true)
			{
				socket = server.accept();
				Thread thread = new Thread(new ServerSample());
				thread.start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				server.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
	public void run()
	{
		try {
			System.out.println(socket);
			BufferedWriter output = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
			String str = "Hello";
			BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			String strinput = input.readLine();
			while(strinput!=null&!strinput.equals(""))
			{
				System.out.println(strinput);
				strinput = input.readLine();
			}
			output.write(str);
			output.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

}
