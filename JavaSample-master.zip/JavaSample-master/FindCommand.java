import java.io.*;

public class FindCommand {
	
	public static void main(String[] args) {
		
		if(args.length != 2) { System.out.println("FindCommand path name"); System.exit(1); }
		
		File file = new File(args[0]);
		
		if(!file.isDirectory()) { System.out.println("path is not exist"); System.exit(1); }
		
		search(file, args[1]);
	
	}

	static void search(File dir, String name) {
		
		File[] list = dir.listFiles();
		if(list != null) {
		for(File file : list) {
			
			if(file.isDirectory()) {			
				search(file, name);			
			} else {
				
				if(file.getName().contains(name)) {
					System.out.println(file.getPath());
				}
			
			}

		}
		}
	}
}
