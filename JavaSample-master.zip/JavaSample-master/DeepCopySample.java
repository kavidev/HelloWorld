public class DeepCopySample implements Cloneable {

	StringBuilder sb = new StringBuilder("value1");
	StringBuilder[] sbArray = new StringBuilder[] {
			new StringBuilder("value1"), new StringBuilder("value2") };
	
	public static DeepCopySample DeepCopy(DeepCopySample source) {
		DeepCopySample newDeepCopySample = new DeepCopySample();
		newDeepCopySample.sb = new StringBuilder(source.sb);
		StringBuilder[] newSbArray = new StringBuilder[source.sbArray.length];
		
		for (int i = 0; i < newSbArray.length; i++) {
			newSbArray[i] = new StringBuilder(source.sbArray[i]);
		}
		
		newDeepCopySample.sbArray = newSbArray;
		
		return newDeepCopySample;
	}
	
	public static void main(String[] args) {

		DeepCopySample deepCopySample１ = new DeepCopySample();
		DeepCopySample deepCopySample2 = (DeepCopySample) deepCopySample１.clone();
		DeepCopySample deepCopySample3 = DeepCopySample.DeepCopy(deepCopySample１);
		deepCopySample１.sb.append("%");
		deepCopySample１.sbArray[0].append("%");
		deepCopySample2.sb.append("*");
		deepCopySample2.sbArray[0].append("*");
		deepCopySample3.sb.append("+");
		deepCopySample3.sbArray[0].append("+");
		
		System.out.println("deepCopySample１.sb = " + deepCopySample１.sb);
		System.out.println("deepCopySample2.sb = " + deepCopySample2.sb);
		System.out.println("deepCopySample3.sb = " + deepCopySample3.sb);
		System.out.println("deepCopySample1.sbArray[0] = " + deepCopySample１.sbArray[0]);
		System.out.println("deepCopySample2.sbArray[0] = " + deepCopySample2.sbArray[0]);
		System.out.println("deepCopySample3.sbArray[0] = " + deepCopySample3.sbArray[0]);
	}

	@Override
	public Object clone() {
		DeepCopySample deepCopySample = null;

		try {

			deepCopySample = (DeepCopySample) super.clone();
			deepCopySample.sb = new StringBuilder(this.sb);
			
			StringBuilder[] source = this.sbArray;
			deepCopySample.sbArray = this.sbArray.clone();
			for (int i = 0; i < source.length; i++) {
				deepCopySample.sbArray[i] = new StringBuilder(source[i]);
			}
						
		} catch (Exception e) {

		}

		return deepCopySample;
	}
}