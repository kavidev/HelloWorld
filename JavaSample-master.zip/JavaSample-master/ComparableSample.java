import java.util.ArrayList;
import java.util.Collections;


public class ComparableSample {

	public static void main(String[] args) {
		ArrayList<Book> list = new ArrayList<>();
		list.add(new Book("Java Programing", "2000", "Yasunaga1"));
		list.add(new Book("Ruby Programing", "3000", "Tanaka"));
		list.add(new Book("C Programing", "2500", "Itou"));
		Collections.sort(list);

		for(Book book : list) {
			System.out.println(book);
		}
	
	}

	static class Book implements Comparable<Book> {
		
		private String title = null;
		
		private String price = null;
		
		private String author = null;
		
		Book(String title, String price, String author) {
			this.title = title;
			this.price = price;
			this.author = author;
		}
		
		public String getTitle() {
			return this.title;
		}
		
		public String getPrice() {
			return this.price;
		}
		
		public String getAuthor() {
			return this.author;
		}
		
		public int compareTo(Book book) {
			if(Integer.valueOf(price) > Integer.valueOf(book.getPrice())) {
				return 1;
			} else if(Integer.valueOf(price) < Integer.valueOf(book.getPrice())) {
				return -1;
			} else {
				return 0;
			}
			//		return title.compareTo(book.getTitle());
		}
		
		public String toString() {
			return "TITLE:" + title + " AUTHOR:" + author + " PRICE:" + price; 
		}
		
	}
}
