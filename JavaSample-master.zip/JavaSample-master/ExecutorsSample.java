import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class ExecutorsSample {

	public static void main(String[] args) {

		ExecutorService executorService = Executors.newFixedThreadPool(2);
		Count count = new Count();
		executorService.execute(count);
		executorService.execute(count);
		executorService.shutdown();
	}
	
	static class Count implements Runnable {
		private AtomicInteger count = new AtomicInteger(0);

		@Override
		public void run() {
			for (int i = 0; i < 10; i++) {
				System.out.println(count.addAndGet(1)
						+ Thread.currentThread().getName());
			}
		}

	}
}

