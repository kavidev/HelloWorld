import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class RegexSample {
	private static final String STR = "ATTB aCCB ADDB";

	public static void main(String[] args) {
		Pattern p1 = Pattern.compile("A.+?B");
		Pattern p2 = Pattern.compile("A.+B");
		Pattern p3 = Pattern.compile("A.+?B", Pattern.CASE_INSENSITIVE);
		Pattern p4 = Pattern.compile("(?i)A.+?B");
		Matcher m1 = p1.matcher(STR);
		while (m1.find()) {
			System.out.println(m1.group());
		}
		System.out.println("");
		m1 = p2.matcher(STR);
		while (m1.find()) {
			System.out.println(m1.group());
		}
		System.out.println("");
		m1 = p3.matcher(STR);
		while (m1.find()) {
			System.out.println(m1.group());
		}
		System.out.println("");
		m1 = p4.matcher(STR);
		while (m1.find()) {
			System.out.println(m1.group());
		}
	}
}
