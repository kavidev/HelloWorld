import java.util.*;
public class TreeMapSample {
	public static void main(String[] args) {
		TreeMap<Book, String> map = new TreeMap<Book, String>();
		map.put(new Book(1111, "aoyama"), "1");
		map.put(new Book(234, "tanaka"), "7");
		map.put(new Book(7777, "itou"), "2");
		map.put(new Book(7777, "ide"), "4");
		map.put(new Book(234, "uchida"), "3");
		Iterator iterator = map.values().iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		System.out.println(map);
		System.out.println("firstKey():" + map.firstKey());
		System.out.println("lastKey():" + map.lastKey());
	}
}

class Book implements Comparable<Book> {
	private Integer price = null;
	private String author = null;
	Book(Integer p, String a) {
		this.price = p;
		this.author = a;
	}
	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Book) {
			Book b = (Book)obj;
			if (this.price.equals(b.price)) {
				return true;
			} else {
				return false;
			}
		}
		return false;
	}
	@Override
	public int compareTo(Book b) {
		if (this.price > b.price) {
			return 1;
		} 
		if (this.author.compareTo(b.author) > 0) {
			return 1;
		} else {
			return -1;
		}
	}
	@Override
	public String toString() {
		return price + ":" + author;
	}
}
