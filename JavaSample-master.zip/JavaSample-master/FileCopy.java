import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.FileSystems;
import java.nio.file.Path;

public class FileCopy
{
	public static void main(String[] args)
	{
		copy1();
		copy2();
	}
		
	static void copy1() {
			
			try {
				File file1 = new File("test1.txt");
				File file2 = new File("test2.txt");
				
				FileChannel channelfile1 = new FileInputStream(file1).getChannel();
				FileChannel channelfile2 = new FileOutputStream(file2).getChannel();
				
				try {
					channelfile1.transferTo(0, channelfile1.size(), channelfile2);
				
				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					channelfile1.close();
					channelfile2.close();
				}
			} catch (IOException e ) {
				e.printStackTrace();
		}
	}
	
	static void copy2() {
		try {
			Path path = FileSystems.getDefault().getPath("test1.txt");
			FileOutputStream output = new FileOutputStream(new File("test2.txt"));
			
			try {
			Files.copy(path, output);
			output.flush();
			
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				output.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
